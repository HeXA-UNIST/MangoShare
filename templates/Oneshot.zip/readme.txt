﻿Oneshot v1.037
==============

개요
--------

원샷(Oneshot)은 RPG 만들기 2003으로 제작된 플레이어 여러분이 이상한 세계에서 길을 잃은 아이를 도와 아이템, 등장인물들, 그리고 주변 환경을 이용해 진행하는 퍼즐/어드벤처 게임입니다.

특징
--------

 - 오리지널 수록곡
 - 자작 그래픽
 - 특이한 게임플레이
 - 영구적 결과

조작
--------

 - 방향키/hjkl:　　　　　캐릭터/커서 이동
 - Z/Space/Enter:　　행동/확인
 - X/N/B/Esc:　　　메뉴/취소
 - Shift:　　　　　현재 아이템 비활성화
 - 숫자 키:　　　빠른 이동 메뉴 여닫기 (야외에서만 가능)

책임
----------

원샷의 일부 특질은 알만툴 게임 혹은 보통의 많은 게임과 다를 수 있습니다. 그러니 놀라지 마세요. 전부 게임의 일부입니다.

그러나 눈(eye)의 묘사 혹은 어둠에 편집적이거나 민감한 경우 주의를 요합니다.

제작
-------

Mathew Velasquez가 대부분의 프로그래밍을 담당했습니다.
NightMargin(Casey Gu)이 대부분의 그래픽과 음악을 담당했습니다.

이 게임은 배포되기 이전에 아래의 분들에 의해 베타 테스트를 거쳤습니다:
TangyOranges            Michael
ZeroGuilt               letty
DolphinsAreEvil         Nekkowe
Mraof                   psychoTR2
Kyne                    Felix
M3ltd0wn

일부 음악에 사용된 FreeSound.org의 샘플링은 아래의 분들이 제작했습니다:
Jovica                  Dymewiz
hanstimm                Freed

효과음은 긁는 소리로 만들거나,Bfxr로 생성하거나 혹은
FreeSound.org에 올라온 아래의 분들이 제작한 효과음을 편집했습니다:
Black Snow              conleec
rivernile7              jacobalcook
reinsamba               kantouth
martinimeniscus         elliottmoo
Adam_N                  RHumphries
luffy                   samararaine
chrisw92                grunz
Autistic Lucario        fins
Mydo1                   kklab5050
D W                     Kyle1Katarn
LG                      soundmary
THE_bizniss             MAJ061785
mmaruska                bevangoldswair
Trautwein               Yoyodaman234
pempi                   Vosvoy

한국어 번역은 토호타쿠(TohoTaku)가 담당했습니다.

이 게임의 여러 그래픽에 사용된 폰트는 Terminus 입니다.
그 외 게임 전체에 사용된 폰트는 MS Gothic과 MS Mincho입니다.

영상, 실황, 기타 2차 창작 정책
---------------------------------------

원작자를 표기하는 한 영상, 실황, 또 기타 2차 창작을 환영하며
또 그것들을 장려합니다!

법 관련 소재
-----------

이 게임은 상용 게임이 아닙니다. 이 게임에 돈을 지불했다면 사기를 당한 것이며, 환불을 요구하도록 합시다.

FreeSound.org에서 가져온 사운드들은 각각 다음의 라이센스 중 하나를 따릅니다:
http://creativecommons.org/publicdomain/zero/1.0/
http://creativecommons.org/licenses/by/3.0/
http://creativecommons.org/licenses/by-nc/3.0/

Terminus는 Open Font License를 따릅니다:
http://scripts.sil.org/OFL

MS Gothic과 MS Mincho 트루타입 폰트는 게임 내에 포함되어있지 않습니다.

비공식으로 개조된 RPG 만들기 2003 런타임 바이너리로 배포되었습니다.
